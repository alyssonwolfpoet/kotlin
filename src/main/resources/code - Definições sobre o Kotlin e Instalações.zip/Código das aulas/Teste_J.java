public class Teste_J {
    public static void main(String[] args) {
        
    }
}
