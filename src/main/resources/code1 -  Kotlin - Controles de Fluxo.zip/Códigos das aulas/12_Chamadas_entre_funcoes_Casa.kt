fun casa(){
    println("Entrando na casa...")
    quarto()
}
fun quarto(){
    println("Passando pelo quarto...")
    guarda_roupa()
}
fun guarda_roupa(){
    println("Passando pelo gaurda roupa...")
    sapato()
}
fun sapato(){
    println("Escolhendo o sapato...")
    cadarco()
}
fun cadarco(){
    println("Escolhendo a cor do cadarço...")
}
fun main() {
    casa()
}