fun main() {
     var x: Int = 18 // Variável mutável
     val y: Int // Variável imutável
     var a: Float = 19.05f
     var b: Double = 3.18474774
     var c: Long = 101001010010109
     var d: Char = 'F'
     var e: String = "Felipe"
     var f: Short = 100
     var g: Byte = 0b11
     var h: Byte = 0x10
     var i: UInt = 12u// Unsigned

    println(a)
    println(x)
    println(b)
    println(c)
    println(d)
    println(e)
    println(f)
    println(g)
    println(h)
    println(i)

}
/*
*
*
*
*
*
*
*
*
* */