fun main() {
    println("ULong máximo: ${ULong.MAX_VALUE} Ulong mínimo: ${ULong.MIN_VALUE}")
    println("UInt máximo: ${UInt.MAX_VALUE} UInt mínimo: ${UInt.MIN_VALUE}")
    println("UShort máximo: ${UShort.MAX_VALUE} UShort mínimo: ${UShort.MIN_VALUE}")
    println("Long máximo: ${Long.MAX_VALUE} long mínimo: ${Long.MIN_VALUE}")
}