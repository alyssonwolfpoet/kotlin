fun main() {
    var t:Int = 19
    var str:String = "Total"

    t++
    str+= " Perfeito"

    println("Printando número: ${t}")
    println("Printando nome: ${str}")


    var B:Boolean = true

    println(B)
}