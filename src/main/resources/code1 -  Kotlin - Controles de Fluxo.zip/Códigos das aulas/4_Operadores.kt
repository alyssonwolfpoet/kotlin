fun main() {
    var h:Boolean = false
    h = !(h)
    println(h)

    println((3+2)*5)
    println(3+2*5)
}

/*
*  OPERADORES LÓGICOS
*       && -> E
*       || -> OU
*       ! -> NEGAÇÃO
*  OPERADORES MATEMÁTICOS
*       + -> ADIÇÃO
*       - -> SUBTRAÇÃO
*       * -> MULTIPLICAÇÃO
*       / -> DIVISÃO
*       % -> RESTO DA DIVISÃO
*  OPERADORES COMPARATIVOS
*       > MAIOR QUE
*       >= MAIOR QUE OU IGUAL
*       < MENOR
*       <= MENOR OU IGUAL
*       == IGUALDADE VOLTADA A COMPARAÇÃO
*       = ATRIBUIÇÃO
*       != DIFERENTE
*
* */