public class NullPointer {
    public static void main(String[] args) {
        String a = null;
        // Código
        System.out.println(a.length());
        System.out.println("Teste JAVA ");
    }
}
