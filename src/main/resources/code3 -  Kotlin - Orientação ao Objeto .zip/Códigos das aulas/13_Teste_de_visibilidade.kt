fun main() {
    //var t:F = F()
    //println(t.teste)
    var c:Computador = Computador("Dell")
    c.ligar()
    c.desligar()
    c.Varredura()
}