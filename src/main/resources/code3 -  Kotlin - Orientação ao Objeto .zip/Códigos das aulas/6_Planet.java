public class Planet {
    private String nome = "Teste";
    private String getNome_(){
        return nome;
    }
    public void setNome_(String nome){
        this.nome = nome;
    }
}
